// // File: screens/PersonalizedQuestions2Screen.js
// import React, { useState } from 'react';
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   StyleSheet,
//   Alert,
// } from 'react-native';

// export default function PersonalizedQuestions2Screen({ navigation }) {
//   const [answer1, setAnswer1] = useState('');
//   const [answer2, setAnswer2] = useState('');
//   const [answer3, setAnswer3] = useState('');

//   const handleNext = () => {
//     if (!answer1 || !answer2 || !answer3) {
//       // Ensure all answers are filled
//       Alert.alert('Error', 'Please answer all questions');
//       return;
//     }
//     navigation.navigate('Splash'); // Navigate to the Home screen
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>General Info</Text>

//       <View style={styles.questionContainer}>
//         <Text style={styles.questionText}>
//           1. Are you facing family pressure?
//         </Text>
//         <TextInput
//           style={styles.input}
//           placeholder="Your answer here"
//           placeholderTextColor="#6C3483"
//           value={answer1}
//           onChangeText={setAnswer1}
//         />
//       </View>

//       <View style={styles.questionContainer}>
//         <Text style={styles.questionText}>
//           2. Are you facing Peer pressure?
//         </Text>
//         <TextInput
//           style={styles.input}
//           placeholder="Your answer here"
//           placeholderTextColor="#6C3483"
//           value={answer2}
//           onChangeText={setAnswer2}
//         />
//       </View>

//       <View style={styles.questionContainer}>
//         <Text style={styles.questionText}>3. Rate your Self-Esteem</Text>
//         <TextInput
//           style={styles.input}
//           placeholder="Your answer here"
//           placeholderTextColor="#6C3483"
//           value={answer3}
//           onChangeText={setAnswer3}
//         />
//       </View>

//       <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
//         <Text style={styles.nextButtonText}>Next</Text>
//       </TouchableOpacity>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: 'center',
//     alignItems: 'center',
//     backgroundColor: '#f0f9ff',
//     padding: 20,
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: 'bold',
//     color: '#4A235A',
//     marginBottom: 30,
//   },
//   questionContainer: {
//     width: '100%',
//     marginBottom: 20,
//   },
//   questionText: {
//     fontSize: 16,
//     fontWeight: 'bold',
//     color: '#4A235A',
//     marginBottom: 10,
//   },
//   input: {
//     width: '100%',
//     borderWidth: 1,
//     borderColor: '#6C3483',
//     borderRadius: 5,
//     padding: 10,
//     color: '#6C3483',
//     backgroundColor: '#fff',
//   },
//   nextButton: {
//     backgroundColor: '#8E44AD',
//     paddingVertical: 10,
//     paddingHorizontal: 20,
//     borderRadius: 5,
//     alignItems: 'center',
//   },
//   nextButtonText: {
//     color: '#fff',
//     fontWeight: 'bold',
//     fontSize: 16,
//   },
// });
