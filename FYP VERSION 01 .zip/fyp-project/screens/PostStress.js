import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

const PostStressScreen = ({ navigation }) => {
  const [insights] = useState([
    'Stress levels dropped significantly after relaxation.',
    'External factors influenced stress levels.',
    'You demonstrated excellent recovery post-exam.',
  ]);

  const activities = [
    { id: 1, title: 'Guided Relaxation Sessions' },
    { id: 2, title: 'Play Relaxing Music' },
    { id: 3, title: 'Post-Exam Stress Relief Games' },
    { id: 4, title: 'Motivational Chats' },
  ];

  const handleActivityPress = (activity) => {
    console.log(`${activity.title} selected`);
    // Implement specific navigation or action for each activity here
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* Header */} 
         <View style={styles.activitiesContainer}>
          <Text style={styles.sectionTitle}>Relaxation Activities</Text>
          {activities.map((activity) => (
            <TouchableOpacity
              key={activity.id}
              style={styles.activityCard}
              onPress={() => handleActivityPress(activity)}
            >
              <Text style={styles.activityText}>{activity.title}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Insights Section */}
        <Text style={styles.sectionTitle}>Post-Exam Insights</Text>
        <View style={styles.insightsContainer}>
       
          {insights.map((insight, index) => (
            <Text key={index} style={styles.insightText}>
              {insight}
            </Text>
          ))}
        </View>

        {/* Activities Section */}
       

        {/* Generate Report Button */}
        <TouchableOpacity
          style={styles.button}
          onPress={() => console.log('Generating Post-Exam Report')}
        >
          <Text style={styles.buttonText}>Generate Report</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
    // borderWidth:2,
  },
  scrollContainer: {
    padding: 10,
    paddingTop:30,
  },
  // header: {
  //   fontSize: 24,
  //   fontWeight: 'bold',
  //   color: '#8E44AD',
  //   textAlign: 'center',
  //   marginBottom: 30,
  // },
  insightsContainer: {
    marginBottom: 20,
    backgroundColor: '#ffffff',
    padding: 15,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 3 },
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#8E44AD',
    marginBottom: 20,
    textAlign: 'center',
  },
  insightText: {
    fontSize: 14,
    color: '#333',
    marginBottom: 5,
    fontWeight: 'bold',
  },
  activitiesContainer: {
    marginBottom: 20,
  },
  activityCard: {
    backgroundColor: '#ffffff',
    padding: 15,
    marginBottom: 10,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 3 },
    elevation: 3,
  },
  activityText: {
    fontSize: 14,
    color: 'black',
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: '#8E44AD',
    paddingVertical: 15,
    borderRadius: 25,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    fontSize: 18,
    color: '#ffffff',
    fontWeight: 'bold',
  },
});

export default PostStressScreen;
