import { View } from 'react-native';

const GradientBackground = ({ children }) => {
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: 'linear-gradient(180deg, #8E44AD, #3498db)',
        alignItems: 'center',
      }}
    >
      {children}
    </View>
  );
};

export default GradientBackground;
