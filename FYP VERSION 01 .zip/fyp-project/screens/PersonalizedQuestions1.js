import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import { ScrollView } from 'react-native-gesture-handler'; // Import Gesture Handler ScrollView

export default function PersonalizedQuestions1Screen({ navigation }) {
  const [answer1, setAnswer1] = useState('');
  const [answer2, setAnswer2] = useState('');
  const [answer3, setAnswer3] = useState('');
  const [answer4, setAnswer4] = useState('');
  const [answer5, setAnswer5] = useState('');
  const [answer6, setAnswer6] = useState('');

  const handleNext = () => {
    if (!answer1 || !answer2 || !answer3 || !answer4 || !answer5 || !answer6) {
      // Ensure all answers are filled
      Alert.alert('Error', 'Please answer all questions');
      return;
    }

    // Pass answers to the HomeScreen
    navigation.navigate('Home', {
      name: answer1,
      age: answer2,
      gender: answer3,
      academicYear: answer4,
      department: answer5,
      cgpa: answer6,
    });
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        <Text style={styles.heading}>Some Personalized Information</Text>

        <View style={styles.questionContainer}>
          <Text style={styles.questionText}>1. What is your name?</Text>
          <TextInput
            style={styles.input}
            placeholder="Your answer here"
            placeholderTextColor="#6C3483"
            value={answer1}
            onChangeText={setAnswer1}
          />
        </View>

        <View style={styles.questionContainer}>
          <Text style={styles.questionText}>2. What is your Age?</Text>
          <TextInput
            style={styles.input}
            placeholder="Your answer here"
            placeholderTextColor="#6C3483"
            value={answer2}
            onChangeText={setAnswer2}
          />
        </View>

        <View style={styles.questionContainer}>
          <Text style={styles.questionText}>3. What is your Gender?</Text>
          <TextInput
            style={styles.input}
            placeholder="Your answer here"
            placeholderTextColor="#6C3483"
            value={answer3}
            onChangeText={setAnswer3}
          />
        </View>

        <View style={styles.questionContainer}>
          <Text style={styles.questionText}>4. What is your Academic year?</Text>
          <TextInput
            style={styles.input}
            placeholder="Your answer here"
            placeholderTextColor="#6C3483"
            value={answer4}
            onChangeText={setAnswer4}
          />
        </View>

        <View style={styles.questionContainer}>
          <Text style={styles.questionText}>5. What is your Department?</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your department name"
            placeholderTextColor="#6C3483"
            value={answer5}
            onChangeText={setAnswer5}
          />
        </View>

        <View style={styles.questionContainer}>
          <Text style={styles.questionText}>6. What is your CGPA?</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your CGPA"
            placeholderTextColor="#6C3483"
            value={answer6}
            onChangeText={setAnswer6}
          />
        </View>

        <TouchableOpacity style={styles.submitButton} onPress={handleNext}>
          <Text style={styles.submitButtonText}>Next</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f9ff',
    padding: 20,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingBottom: 30, // Added some extra bottom padding for smooth scrolling
  },
  heading: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#8E44AD',
    marginBottom: 30,
  },
  questionContainer: {
    width: '100%',
    marginBottom: 20,
  },
  questionText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4A235A',
    marginBottom: 10,
  },
  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#6C3483',
    borderRadius: 5,
    padding: 10,
    color: '#6C3483',
    backgroundColor: '#fff',
  },
  submitButton: {
    backgroundColor: '#8E44AD',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    alignItems: 'center',
  },
  submitButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
