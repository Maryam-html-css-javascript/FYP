import React, { useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, SafeAreaView, ScrollView, Animated } from 'react-native';
import { AnimatedCircularProgress } from 'react-native-circular-progress';

export default function HomeScreen({ navigation, route }) {
  const scaleAnimation = useRef(new Animated.Value(1)).current;

  // Retrieve personalized data from the route params
  const personalizedData = route.params?.personalizedData;

  const handlePressIn = () => {
    Animated.timing(scaleAnimation, {
      toValue: 0.9,
      duration: 150,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.timing(scaleAnimation, {
      toValue: 1,
      duration: 150,
      useNativeDriver: true,
    }).start();
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Exam Ease</Text>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Display personalized information if available */}
        {personalizedData && (
          <View style={styles.personalizedInfoContainer}>
            <Text style={styles.personalizedText}>Your Personalized Data:</Text>
            <Text style={styles.personalizedText}>Answer 1: {personalizedData.answer1}</Text>
            <Text style={styles.personalizedText}>Answer 2: {personalizedData.answer2}</Text>
            {/* Add other answers or information here */}
          </View>
        )}

        {/* Metrics Container */}
        <View style={styles.metricsContainer}>
          <View style={styles.metricBox}>
            <AnimatedCircularProgress
              size={120}
              width={8}
              fill={70}
              tintColor="#8E44AD"
              backgroundColor="#dcdcdc"
              rotation={0}
              duration={1500}
            >
              {() => (
                <>
                  <Text style={styles.metricValue}>70%</Text>
                  <Text style={styles.metricLabel}>HeartRate</Text>
                </>
              )}
            </AnimatedCircularProgress>
          </View>

          <View style={styles.metricBox}>
            <AnimatedCircularProgress
              size={120}
              width={8}
              fill={50}
              tintColor="#8E44AD"
              backgroundColor="#dcdcdc"
              rotation={0}
              duration={1500}
            >
              {() => (
                <>
                  <Text style={styles.metricValue}>37°C</Text>
                  <Text style={styles.metricLabel}>Temperature</Text>
                </>
              )}
            </AnimatedCircularProgress>
          </View>
        </View>

        {/* Buttons */}
        <View style={styles.buttonContainer}>
          {/* Button Sections */}
          <View style={styles.buttonOuterShadow}>
            <View style={styles.buttonInnerShadow}>
              <View style={styles.buttonContent}>
                <Text style={styles.buttonText}>PRE EXAM STRESS</Text>
                <Image
                  source={require('../assets/images/pre_exam.png')}
                  style={styles.buttonImage}
                />
              </View>
              <Animated.View style={{ transform: [{ scale: scaleAnimation }] }}>
                <TouchableOpacity
                  style={[styles.openButton, styles.openButtonLeft]}
                  onPressIn={handlePressIn}
                  onPressOut={handlePressOut}
                  onPress={() => navigation.navigate('PreStress')}
                >
                  <Text style={styles.openButtonText}>Open</Text>
                </TouchableOpacity>
              </Animated.View>
            </View>
          </View>

          <View style={styles.buttonOuterShadow}>
            <View style={styles.buttonInnerShadow}>
              <View style={styles.buttonContent}>
                <Text style={styles.buttonText}>Real-Time Exam Stress</Text>
                <Image
                  source={require('../assets/images/during_eaxm.png')}
                  style={styles.buttonImage}
                />
              </View>
              <Animated.View style={{ transform: [{ scale: scaleAnimation }] }}>
                <TouchableOpacity
                  style={[styles.openButton, styles.openButtonLeft]}
                  onPressIn={handlePressIn}
                  onPressOut={handlePressOut}
                  onPress={() => navigation.navigate('DuringStress')}
                >
                  <Text style={styles.openButtonText}>Open</Text>
                </TouchableOpacity>
              </Animated.View>
            </View>
          </View>

          <View style={styles.buttonOuterShadow}>
            <View style={styles.buttonInnerShadow}>
              <View style={styles.buttonContent}>
                <Text style={styles.buttonText}>POST EXAM STRESS</Text>
                <Image
                  source={require('../assets/images/post_eaxm.png')}
                  style={styles.buttonImage}
                />
              </View>
              <Animated.View style={{ transform: [{ scale: scaleAnimation }] }}>
                <TouchableOpacity
                  style={[styles.openButton, styles.openButtonLeft]}
                  onPressIn={handlePressIn}
                  onPressOut={handlePressOut}
                  onPress={() => navigation.navigate('PostStress')}
                >
                  <Text style={styles.openButtonText}>Open</Text>
                </TouchableOpacity>
              </Animated.View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
    paddingTop: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#fff',
    marginVertical: 10,
    fontStyle: 'italic',
    backgroundColor: '#8E44AD',
    padding: 10,
  },
  personalizedInfoContainer: {
    padding: 15,
    backgroundColor: '#f7f7f7',
    marginVertical: 10,
    borderRadius: 10,
  },
  personalizedText: {
    fontSize: 16,
    color: '#333',
  },
  metricsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 5,
  },
  metricBox: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  metricValue: {
    fontSize: 20,
    color: '#8E44AD',
    fontWeight: 'bold',
  },
  metricLabel: {
    fontSize: 14,
    color: '#8E44AD',
    fontStyle: 'italic',
    fontWeight: 'bold',
    marginTop: 5,
  },
  buttonContainer: {
    marginBottom: 20,
  },
  buttonOuterShadow: {
    backgroundColor: '#f7f7f7',
    padding: 5,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 4,
    marginVertical: 10,
  },
  buttonInnerShadow: {
    backgroundColor: '#ffff',
    borderRadius: 10,
    padding: 10,
    shadowColor: '#fff',
    shadowOffset: { width: -5, height: -5 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
    height: 100,
    width: '100%',
  },
  buttonText: {
    fontSize: 16,
    color: 'black',
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  buttonImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  openButton: {
    position: 'absolute',
    bottom: -10,
    backgroundColor: '#8E44AD',
    borderRadius: 5,
    paddingVertical: 5,
    paddingHorizontal: 15,
  },
  openButtonLeft: {
    left: 10,
  },
  openButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
    textAlign: 'center',
  },
});
