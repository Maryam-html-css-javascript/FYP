import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';

const DuringStressScreen = ({ navigation }) => {
  const [stressLevel, setStressLevel] = useState(5); // Initial stress level for decision-making
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [tips, setTips] = useState([]);

  // Simulate real-time stress monitoring
  useEffect(() => {
    const stressMonitor = setInterval(() => {
      const randomStress = Math.floor(Math.random() * 100); // Random stress level between 0-100
      setStressLevel(randomStress);

      // Provide feedback based on stress level
      if (randomStress > 70) {
        setTips([
          'Take deep breaths when you feel overwhelmed.',
          'Do a quick stretching exercise.',
          'Try guided meditation.',
        ]);
      } else if (randomStress > 40) {
        setTips([
          'Focus on the present moment.',
          'Take short breaks to stay composed.',
          'Visualize a calming environment.',
        ]);
      } else {
        setTips([
          'Keep up the good work!',
          'Stay positive and maintain your momentum.',
          'Remember to drink water and stay hydrated.',
        ]);
      }
    }, 5000); // Update every 5 seconds

    return () => clearInterval(stressMonitor); // Cleanup interval
  }, []);

  const activities = [
    { id: 1, title: 'Quick Breathing Exercises' },
    { id: 2, title: 'Focus Improvement Activities' },
    { id: 3, title: 'Guided Meditation' },
    { id: 4, title: 'Motivational Quotes' },
    { id: 5, title: 'Stretching Exercises' },
  ];

  const handleActivityPress = (activity) => {
    console.log(`${activity.title} selected`);
    // Implement specific navigation or action for each activity here
  };

  const handleReturnToDashboard = () => {
    if (stressLevel >= 5) {
      // If stress level is high, show a warning
      Alert.alert(
        'High Stress Level Detected',
        'Your stress level is still high. Would you like to try some relaxation activities before returning?',
        [
          { text: 'Yes', onPress: () => console.log('Relaxation Activities Selected') },
          { text: 'No', onPress: () => navigation.navigate('Home') }, // Navigate to Home screen
        ]
      );
    } else {
      // If stress level is manageable, return to dashboard
      navigation.navigate('Dashboard');
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* Header */}
        {/* Stress Level Display */}
        <View style={styles.stressLevelContainer}>
          <Text style={styles.stressLevel}>Current Stress Level: {stressLevel}</Text>
        </View>

        {/* Tips Section */}
        <Text style={styles.sectionTitle}>Quick Stress-Relief Tips</Text>
        <View style={styles.tipsContainer}>
          {tips.map((tip, index) => (
            <Text key={index} style={styles.tipText}>
              {index + 1}. {tip}
            </Text>
          ))}
        </View>

        {/* Activities Section */}
        <Text style={styles.sectionTitle}>Stress-Relief Activities</Text>
        <View style={styles.activitiesContainer}>
          {activities.map((activity) => (
            <TouchableOpacity
              key={activity.id}
              style={styles.activityCard}
              onPress={() => handleActivityPress(activity)}
            >
              <Text style={styles.activityText}>{activity.title}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Return to Dashboard Button */}
        <TouchableOpacity
          style={styles.button}
          onPress={handleReturnToDashboard}
        >
          <Text style={styles.buttonText}>Return to Dashboard</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
  },
  scrollContainer: {
    padding: 20,
    paddingBottom: 40,
    marginTop:20,
  },
  // header: {
  //   fontSize: 22,
  //   fontWeight: 'bold',
  //   color: '#8E44AD',
  //   textAlign: 'center',
  //   marginBottom: 20,
  // },
  stressLevelContainer: {
    backgroundColor: '#fff4e1', // Light yellow for stress level container
    padding: 10,
    borderRadius: 10,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOpacity: 0.05, // Reduced shadow opacity
    shadowRadius: 5, // Reduced shadow radius
    shadowOffset: { width: 0, height: 0 },
    elevation: 2, // Reduced elevation
  },
  stressLevel: {
    fontSize: 22,
    color: '#d9534f', // Red tone for high stress
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#8E44AD',
    marginBottom: 10,
    textAlign: 'center',
  },
  tipsContainer: {
    marginBottom: 30,
    backgroundColor: '#ffffff',
    padding: 15,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOpacity: 0.05, // Reduced shadow opacity
    shadowRadius: 5, // Reduced shadow radius
    shadowOffset: { width: 0.1, height: 2 },
    elevation: 2, // Reduced elevation
  },
  tipText: {
    fontSize: 14,
    color: '#333',
    marginBottom: 10,
    fontWeight: 'bold',
  },
  activitiesContainer: {
    marginBottom: 20,
  },
  activityCard: {
    backgroundColor: '#ffffff',
    padding: 15,
    marginBottom: 10,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOpacity: 0.05, // Reduced shadow opacity
    shadowRadius: 5, // Reduced shadow radius
    shadowOffset: { width: 0, height: 4 },
    elevation: 2, // Reduced elevation
  },
  activityText: {
    fontSize: 14,
    color: '#333',
    fontWeight: 'bold',
    // textAlign: 'center',
  },
  button: {
    backgroundColor: '#8E44AD',
    paddingVertical: 15,
    borderRadius: 25,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.05, // Reduced shadow opacity
    shadowRadius: 5, // Reduced shadow radius
    shadowOffset: { width: 0, height: 4 },
    elevation: 2, // Reduced elevation
    marginTop: 20,
  },
  buttonText: {
    fontSize: 18,
    color: '#ffffff',
    fontWeight: 'bold',
  },
});

export default DuringStressScreen;
