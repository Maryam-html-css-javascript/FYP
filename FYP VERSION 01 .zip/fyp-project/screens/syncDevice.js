import React, { useRef, useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Alert,
  Image,
} from 'react-native';
import { AnimatedCircularProgress } from 'react-native-circular-progress';

const SyncWearableScreen = ({ navigation }) => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [highlight, setHighlight] = useState(false);
  const scaleAnimation = useRef(new Animated.Value(1)).current;

  const startConnection = () => {
    setIsConnecting(true);
    const timer = setTimeout(() => {
      setIsConnecting(false);
      setIsConnected(true);
      setHighlight(true);
      Alert.alert('Connected', 'Your wearable device is now connected!');
      
      // Navigate to the next screen after 2 seconds
      setTimeout(() => {
        navigation.navigate('Home'); // Replace 'NextScreen' with the actual screen name
      }, 2000);
    }, 4000);

    return () => clearTimeout(timer);
  };

  const handleDisconnect = () => {
    setIsConnected(false);
    navigation.navigate('ReconnectWearableScreen');
  };

  const handlePressIn = () => {
    Animated.timing(scaleAnimation, {
      toValue: 0.9,
      duration: 150,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.timing(scaleAnimation, {
      toValue: 1,
      duration: 150,
      useNativeDriver: true,
    }).start();
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Sync Your Wearable</Text>
      <View style={styles.syncContainer}>
        <Animated.View style={{ transform: [{ scale: scaleAnimation }] }}>
          <AnimatedCircularProgress
            size={180}
            width={10}
            fill={isConnected ? 100 : isConnecting ? 100 : 0}
            tintColor="#8E44AD"
            backgroundColor="#dcdcdc"
            rotation={0}
            duration={4000}
            onAnimationComplete={() => {
              if (isConnecting) {
                setIsConnecting(false);
                setIsConnected(true);
              }
            }}
          />
          <View style={styles.iconContainer}>
            <Image
              source={require('../assets/images/watch.png')}
              style={styles.iconImage}
            />
          </View>
        </Animated.View>
        <Text
          style={[
            styles.statusText,
            highlight && styles.highlightedStatusText,
          ]}
        >
          {isConnecting
            ? 'Connecting to Device...'
            : isConnected
            ? 'Device Connected'
            : ''}
        </Text>
      </View>

      {!isConnected && !isConnecting && (
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.connectButton}
            onPress={startConnection}
            onPressIn={handlePressIn}
            onPressOut={handlePressOut}
          >
            <Text style={styles.buttonText}>Connect Device</Text>
          </TouchableOpacity>
        </View>
      )}

      {isConnected && (
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.disconnectButton}
            onPress={handleDisconnect}
            onPressIn={handlePressIn}
            onPressOut={handlePressOut}
          >
            <Text style={styles.buttonText}>Disconnect</Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 60,
  },
  syncContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 40,
    width: '100%',
  },
 iconContainer: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    width: 180, // Match the AnimatedCircularProgress size
    height: 180, // Match the AnimatedCircularProgress size
  },
  iconImage: {
    width: 60,
    height: 60,
    resizeMode: 'contain',
  },
  statusText: {
    fontSize: 18,
    marginTop: 20,
    color: '#000',
  },
  highlightedStatusText: {
    color: '#8E44AD',
    fontWeight: 'bold',
    textShadowColor: '#8E44AD',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  buttonContainer: {
    marginTop: 10,
  },
  disconnectButton: {
    backgroundColor: '#8E44AD',
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 5,
  },
  connectButton: {
    backgroundColor: '#8E44AD',
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 5,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
  },
});

export default SyncWearableScreen;
