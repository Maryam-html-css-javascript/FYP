import React, { useState, useCallback, useEffect } from "react";
import {
  View,
  StyleSheet,
  Text,
  TouchableOpacity,
  KeyboardAvoidingView,
  TouchableWithoutFeedback,
  Keyboard,
} from "react-native";
import { GiftedChat, InputToolbar, Send } from "react-native-gifted-chat";
import axios from "axios";
import { Ionicons } from "@expo/vector-icons";

const Chatbot = ({ navigation }) => {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState("");

  // Initialize with the greeting message
  useEffect(() => {
    setMessages([
      {
        _id: 1,
        text: "Hi! I'm here to help you manage stress. How can I assist you today?",
        createdAt: new Date(),
        user: {
          _id: 2,
          name: "StressBot",
        },
      },
    ]);
  }, []);

  // Add refresh button in the header
  useEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity onPress={handleRefresh} style={styles.headerRefreshButton}>
          <Ionicons name="refresh" size={24} color="#8E44AD" />
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  // Function to send user input to the chat
  const onSend = useCallback((newMessages = []) => {
    setMessages((previousMessages) =>
      GiftedChat.append(previousMessages, newMessages)
    );

    const userMessage = newMessages[0].text;
    getBotResponse(userMessage); // Call the bot response function with the user input
  }, []);

  // Function to get the bot's response from the OpenAI API
  const getBotResponse = async (userMessage) => {
    try {
      const response = await axios.post(
        "https://api.openai.com/v1/chat/completions",
        {
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "You are a helpful assistant for stress management." },
            { role: "user", content: userMessage },
          ],
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer YOUR_OPENAI_API_KEY`,
          },
        }
      );

      const botMessage = response.data.choices[0].message.content;

      // Append the bot's response to the chat
      setMessages((previousMessages) =>
        GiftedChat.append(previousMessages, [
          {
            _id: Math.random().toString(36).substring(7),
            text: botMessage,
            createdAt: new Date(),
            user: {
              _id: 2,
              name: "StressBot",
            },
          },
        ])
      );
    } catch (error) {
      console.error(error);
      setMessages((previousMessages) =>
        GiftedChat.append(previousMessages, [
          {
            _id: Math.random().toString(36).substring(7),
            text: "Sorry, I couldn't process your request. Please try again.",
            createdAt: new Date(),
            user: {
              _id: 2,
              name: "StressBot",
            },
          },
        ])
      );
    }
  };

  // Refresh button handler to clear the chat
  const handleRefresh = () => {
    setMessages([
      {
        _id: 1,
        text: "Hi! I'm here to help you manage stress. How can I assist you today?",
        createdAt: new Date(),
        user: {
          _id: 2,
          name: "StressBot",
        },
      },
    ]);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
      <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
        <View style={styles.container}>
          {/* Tagline at the top */}
          <Text style={styles.tagline}>Your Stress-Free Assistant</Text>

          <GiftedChat
            messages={messages}
            onSend={(messages) => onSend(messages)}
            user={{
              _id: 1,
            }}
            renderBubble={(props) => {
              const isUser = props.currentMessage.user._id === 1;
              return (
                <View
                  style={[
                    styles.messageBubble,
                    isUser ? styles.userBubble : styles.botBubble,
                  ]}
                >
                  <Text style={styles.messageText}>{props.currentMessage.text}</Text>
                </View>
              );
            }}
            renderAvatar={(props) => {
              const isUser = props.currentMessage.user._id === 1;
              return isUser ? (
                <View
                  style={[styles.avatar, { backgroundColor: "#8E44AD" }]}
                >
                  <Text style={styles.avatarText}>U</Text>
                </View>
              ) : null;
            }}
            renderInputToolbar={(props) => (
              <InputToolbar
                {...props}
                containerStyle={styles.inputContainer}
                primaryStyle={{ alignItems: "center" }}
                textInputStyle={styles.inputText}
              />
            )}
            renderSend={(props) => (
              <Send {...props}>
                <TouchableOpacity style={styles.sendButton}>
                  <Ionicons name="send" size={24} color="#fff" />
                </TouchableOpacity>
              </Send>
            )}
          />
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f0f9ff",
    padding: 10,
  },
  tagline: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#8E44AD",
    textAlign: "center",
    marginBottom: 20,
    marginTop: 10,
  },
  headerRefreshButton: {
    marginRight: 10,
  },
  messageBubble: {
    marginVertical: 5,
    padding: 15,
    borderRadius: 15,
    maxWidth: "75%",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 2,
  },
  userBubble: {
    alignSelf: "flex-end",
    backgroundColor: "#fff",
  },
  botBubble: {
    alignSelf: "flex-start",
    backgroundColor: "#fff",
  },
  messageText: {
    fontSize: 14,
    color: "#000",
  },
  inputContainer: {
    borderRadius: 10,
    borderColor: "#8E44AD",
    borderWidth: 2,
    marginHorizontal: 10,
    marginVertical: 5,
    backgroundColor: "#8E44AD",
  },
  inputText: {
    color: "#fff",
    fontSize: 16,
  },
  sendButton: {
    height: 40,
    width: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  avatarText: {
    fontSize: 20,
    color: "#fff",
    fontWeight: "bold",
  },
});

export default Chatbot;
