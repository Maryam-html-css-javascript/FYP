import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Switch, 
  TouchableOpacity, 
  Alert, 
  SafeAreaView 
} from 'react-native';
import { Picker } from '@react-native-picker/picker';  // Import Picker from the package

export default function SettingsScreen() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const [isDarkTheme, setIsDarkTheme] = useState(false);

  const handleToggleNotifications = () => {
    setNotificationsEnabled(previousState => !previousState);
  };

  const handleThemeChange = () => {
    setIsDarkTheme(previousState => !previousState);
  };

  const handleResetApp = () => {
    Alert.alert(
      'Reset App',
      'Are you sure you want to reset all app data?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'OK', onPress: () => console.log('App Reset') },
      ]
    );
  };

  const handleAboutPress = () => {
    Alert.alert('About Exam Stress Detection', 'This app helps you manage stress during exams through real-time data from a wearable device.');
  };

  return (
    <SafeAreaView style={[styles.container, isDarkTheme ? styles.darkTheme : null]}>
      
      {/* Notifications Toggle */}
      <View style={styles.settingItem}>
        <Text style={[styles.label, isDarkTheme ? styles.darkText : null]}>Enable Notifications</Text>
        <Switch
          value={notificationsEnabled}
          onValueChange={handleToggleNotifications}
        />
      </View>

      {/* Language Selection */}
      <View style={styles.settingItem}>
        <Text style={[styles.label, isDarkTheme ? styles.darkText : null]}>Select Language</Text>
        <Picker
          selectedValue={selectedLanguage}
          style={[styles.picker, isDarkTheme ? styles.darkText : null]}
          onValueChange={(itemValue) => setSelectedLanguage(itemValue)}
        >
          <Picker.Item label="English" value="English" />
          <Picker.Item label="Spanish" value="Spanish" />
          <Picker.Item label="French" value="French" />
        </Picker>
      </View>

      {/* Theme Switch */}
      <View style={styles.settingItem}>
        <Text style={[styles.label, isDarkTheme ? styles.darkText : null]}>Enable Dark Theme</Text>
        <Switch
          value={isDarkTheme}
          onValueChange={handleThemeChange}
        />
      </View>

      {/* Reset App Button */}
      <TouchableOpacity style={[styles.button, styles.buttonReset]} onPress={handleResetApp}>
        <Text style={styles.buttonText}>Reset App Data</Text>
      </TouchableOpacity>

      {/* About Button */}
      <TouchableOpacity style={[styles.button, styles.buttonAbout]} onPress={handleAboutPress}>
        <Text style={styles.buttonText}>About This App</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,  // Ensure the container takes the full height
    padding: 20,
    backgroundColor: '#f0f9ff',
    paddingTop: 60,
  },
  darkTheme: {
    backgroundColor: '#333',
  },
  darkText: {
    color: '#fff',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
  },
  label: {
    fontSize: 18,
  },
  picker: {
    height: 50,
    width: 150,
  },
  button: {
    width: '100%',
    backgroundColor: '#8E44AD',
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 4,
    marginVertical: 10,
  },
  buttonReset: {
    position: 'absolute',
    bottom: 80,  // Adjust distance from the bottom
    left:20,
  },
  buttonAbout: {
    position: 'absolute',
    bottom: 20,  // Adjust distance from the bottom
    left:20,
  },
  buttonText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
});
