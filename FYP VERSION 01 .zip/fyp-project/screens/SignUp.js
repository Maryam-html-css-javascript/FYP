// File: screens/SignUp.js
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ImageBackground,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function SignUpScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignUp = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    const user = await AsyncStorage.getItem(email);
    if (user) {
      Alert.alert('Error', 'User already exists');
    } else {
      const newUser = { email, password };
      await AsyncStorage.setItem(email, JSON.stringify(newUser));
      Alert.alert('Success', 'Account created successfully');
      navigation.navigate('Login');
    }
  };
  return (
    <View style={styles.container}>
      <ImageBackground
        source={{ uri: 'https://your-background-image-url' }}
        style={styles.background}>
        <View style={styles.logoContainer}>
          <View style={styles.logo}>
            <Ionicons name="person" size={60} color="#9b59b6" />
          </View>
        </View>
        <Text style={styles.title}>SIGN UP</Text>

        <View style={styles.inputContainer}>
          <Ionicons
            name="person"
            size={20}
            color="#6C3483"
            style={styles.icon}
          />
          <TextInput
            placeholder="Username"
            placeholderTextColor="#6C3483"
            style={styles.input}
            value={username}
            onChangeText={setUsername}
          />
        </View>

        <View style={styles.inputContainer}>
          <Ionicons name="mail" size={20} color="#6C3483" style={styles.icon} />
          <TextInput
            placeholder="Email"
            placeholderTextColor="#6C3483"
            style={styles.input}
            value={email}
            onChangeText={setEmail}
          />
        </View>

        <View style={styles.inputContainer}>
          <Ionicons
            name="lock-closed"
            size={20}
            color="#6C3483"
            style={styles.icon}
          />
          <TextInput
            placeholder="Password"
            placeholderTextColor="#6C3483"
            secureTextEntry
            style={styles.input}
            value={password}
            onChangeText={setPassword}
          />
        </View>

        <TouchableOpacity style={styles.signUpButton} onPress={handleSignUp}>
          <Text style={styles.signUpButtonText}>SIGN UP</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text style={styles.link}>Already have an account</Text>
        </TouchableOpacity>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:'#f0f9ff',
  },
  background: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  logo: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#f5f5f5',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4A235A',
    marginBottom: 30,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 25,
    width: '80%',
    borderBottomWidth: 1,
    borderColor: '#6C3483',
  },
  icon: {
    marginRight: 8,
  },

  input: {
    flex: 1,
    padding: 10,
    color: '#6C3483',
  },
  signUpButton: {
   width: '80%',
    backgroundColor: '#8E44AD',
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 4,
    marginVertical: 10,
  },
  signUpButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  link: {
    color: '#6C3483',
    marginTop: 10,
    fontSize: 15,
  },
});
