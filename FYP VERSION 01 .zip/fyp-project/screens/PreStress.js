import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import Slider from '@react-native-community/slider';

const PreStressScreen = ({ navigation }) => {
  const [stressLevel, setStressLevel] = useState(5);

  const activities = [
    { id: 1, title: 'Breathing Exercises' },
    { id: 2, title: 'Meditation' },
    { id: 3, title: 'Stress Management Tips' },
    { id: 4, title: 'Journaling' },
    { id: 5, title: 'Soothing Music' },
    { id: 6, title: 'Physical Exercises' },
  ];

  return (
    <View style={styles.container}>
      {/* Header */}

      {/* Stress Level Slider */}
      <View style={styles.stressLevelContainer}>
        <Text style={styles.sliderLabel}>Your Stress Level: {stressLevel}</Text>
        <Slider
          style={styles.slider}
          minimumValue={0}
          maximumValue={10}
          step={1}
          value={stressLevel}
          onValueChange={(value) => setStressLevel(value)}
          minimumTrackTintColor="#8E44AD"
          maximumTrackTintColor="#cccccc"
          thumbTintColor="#8E44AD"
        />
      </View>

      {/* Activities */}
      <ScrollView style={styles.activitiesContainer}>
        {activities.map((activity) => (
          <TouchableOpacity
            key={activity.id}
            style={styles.activityCard}
            onPress={() => console.log(`${activity.title} pressed`)}
          >
            <Text style={styles.activityText}>{activity.title}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Get Ready Button */}
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('GetReady')}
      >
        <Text style={styles.buttonText}>Get Ready</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f9ff',
    padding: 30,
  },
  // header: {
  //   fontSize: 24,
  //   fontWeight: 'bold',
  //   color: '#8E44AD',
  //   textAlign: 'center',
  //   marginBottom: 20,
  // },
  stressLevelContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  sliderLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#8E44AD',
    marginBottom: 10,
  },
  slider: {
    width: '100%',
    height: 40,
  },
  activitiesContainer: {
    flex: 1,
  },
  activityCard: {
    backgroundColor: '#ffffff',
    padding: 15,
    marginBottom: 10,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 3 },
    elevation: 3,

  },
  activityText: {
    fontSize: 14,
    color: 'black',
    fontWeight:'bold',
  },
  button: {
    backgroundColor: '#8E44AD',
    paddingVertical: 15,
    borderRadius: 25,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    fontSize: 18,
    color: '#ffffff',
    fontWeight: 'bold',
  },
});

export default PreStressScreen;
