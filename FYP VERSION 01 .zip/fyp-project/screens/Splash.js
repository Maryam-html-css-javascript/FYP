import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
} from 'react-native';

const SplashScreen = ({ navigation }) => {
  const [waveAnim] = useState(new Animated.Value(0)); // For wave animation
  const [loaderWidth] = useState(new Animated.Value(0)); // For horizontal loader

  useEffect(() => {
    // Wave animation loop
    Animated.loop(
      Animated.sequence([
        Animated.timing(waveAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(waveAnim, {
          toValue: 0,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Horizontal loader animation
    Animated.timing(loaderWidth, {
      toValue: 1,
      duration: 4000,
      useNativeDriver: false,
    }).start(() => {
      // Navigate to the next screen after loader animation completes
      navigation.navigate('Login');
    });
  }, [waveAnim, loaderWidth, navigation]);

  return (
    <View style={styles.container}>
      {/* App Name */}
      <Text style={styles.appName}>Exam Ease</Text>

      {/* Animated Wave with Tagline */}
      <Animated.View
        style={[
          styles.wave,
          {
            opacity: waveAnim.interpolate({ inputRange: [0, 1], outputRange: [0.8, 1] }),
            transform: [
              {
                scale: waveAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [1, 1.1],
                }),
              },
            ],
          },
        ]}
      >
        <Text style={styles.tagline}>Master Your Exams with Confidence</Text>
      </Animated.View>

      {/* Horizontal Loader */}
      <View style={styles.loaderContainer}>
        <View style={styles.loaderBackground}>
          <Animated.View
            style={[
              styles.loaderFill,
              {
                width: loaderWidth.interpolate({
                  inputRange: [0, 1],
                  outputRange: ['0%', '100%'], // Fills horizontally
                }),
              },
            ]}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f9fc', // Light soothing background color
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 20,
  },
  appName: {
    fontSize: 40,
    fontWeight: 'bold',
    color: '#8E44AD',
    textAlign: 'center',
    marginBottom: 30,
    fontStyle: 'italic',
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 5,
  },
  tagline: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#4a4a4a',
    textAlign: 'center',
    paddingHorizontal: 30,
    marginBottom: 20,
  },
  loaderContainer: {
    width: '80%',
    height: 10,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    bottom: 40,
  },
  loaderBackground: {
    width: '100%',
    height: '100%',
    backgroundColor: '#e6e6e6', // Subtle gray loader background
    borderRadius: 10,
    overflow: 'hidden',
  },
  loaderFill: {
    height: '100%',
    backgroundColor: '#8E44AD', // Purple color for loader progress
    borderRadius: 10,
  },
});

export default SplashScreen;
