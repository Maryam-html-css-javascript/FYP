import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { MaterialCommunityIcons } from '@expo/vector-icons'; // Correct import
// Import Screens
import SplashScreen from './screens/Splash';
import LoginScreen from './screens/Login';
import SignUpScreen from './screens/SignUp';
import PersonalizedQuestions1Screen from './screens/PersonalizedQuestions1';
import SyncWearableScreen from './screens/syncDevice';
// import PersonalizedQuestions2Screen from './screens/personalizedQuestions2';
// import PersonalizedQuestions3Screen from './screens/personalizedQuestions3';
import HomeScreen from './screens/Home';
import ThankYouScreen from './screens/ThankYou';
import PreStressScreen from './screens/PreStress';
import DuringStressScreen from './screens/DuringStress';
import PostStressScreen from './screens/PostStress';
import ChatBotScreen from './screens/bottom_tab/ChatBot';
import SettingScreen from './screens/bottom_tab/Setting';
import ExploreScreen from './screens/bottom_tab/Explore';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const getBackArrowHeader = (navigation) => ({
  headerLeft: () => (
    <Ionicons
      name="arrow-back"
      size={24}
      color="#8E44AD"
      style={{ marginLeft: 10 }}
      onPress={() => navigation.goBack()} // Go back to the previous screen
    />
  ),
  gestureEnabled: true, // Enable swipe-to-go-back gesture
  gestureDirection: 'horizontal', // Horizontal swipe gesture
});
function BottomTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        // tabBarStyle: hideTabs ? { display: 'none' } : {},
        tabBarIcon: ({ color, size }) => {
          let iconName;

          if (route.name === 'Home') {
            iconName = 'home';
            return <Ionicons name={iconName} size={size} color={color} />;
          } else if (route.name === 'ChatBot') {
            iconName = 'robot-happy-outline';
            return (
              <MaterialCommunityIcons
                name={iconName}
                size={size}
                color={color}
              />
            );
          } else if (route.name === 'Setting') {
            iconName = 'settings';
            return <Ionicons name={iconName} size={size} color={color} />;
          } else if (route.name === 'Explore') {
            iconName = 'compass';
            return <Ionicons name={iconName} size={size} color={color} />;
          }
          return null;
        },
        tabBarActiveTintColor: '#8E44AD',
        tabBarInactiveTintColor: 'black',
        tabBarLabelStyle: { fontSize: 12, fontWeight: 'bold', marginBottom: 5 },
        tabBarStyle: { height: 60, backgroundColor: '#ffffff' },
      })}>
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="ChatBot"
        component={ChatBotScreen}
        options={({ navigation }) => ({
            title: 'Chatbot',
            ...getBackArrowHeader(navigation),
          })}
      />
      <Tab.Screen
        name="Explore"
        component={ExploreScreen}
       options={({ navigation }) => ({
            title: 'Explore',
            ...getBackArrowHeader(navigation),
          })}
      />
      <Tab.Screen
        name="Setting"
        component={SettingScreen}
        options={({ navigation }) => ({
            title: 'Setting',
            ...getBackArrowHeader(navigation),
          })}
      />
    </Tab.Navigator>
  );
}

// Main App Navigator
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="syncDevice">
        <Stack.Screen
          name="Splash"
          component={SplashScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={({ navigation }) => ({
            title: 'Login',
            ...getBackArrowHeader(navigation),
          })}
        />
        <Stack.Screen
          name="SignUp"
          component={SignUpScreen}
          options={({ navigation }) => ({
            title: 'Sign Up',
            ...getBackArrowHeader(navigation),
          })}
        />
        <Stack.Screen name="Chatbot"
         component={ ChatBotScreen} />
        <Stack.Screen
          name="Home"
          component={BottomTabNavigator}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="PreStress"
          component={PreStressScreen}
          options={({ navigation }) => ({
            title: 'Manage Pre Exam Stress',
            ...getBackArrowHeader(navigation),
          })}
        />
        <Stack.Screen
          name="syncDevice"
          component={SyncWearableScreen}
          options={({ navigation }) => ({
            title: "Sync Device",
            ...getBackArrowHeader(navigation),
          })}
        />
        <Stack.Screen
          name="DuringStress"
          component={DuringStressScreen}
          options={({ navigation }) => ({
            title: 'Manage During Exam Stress',
            ...getBackArrowHeader(navigation),
          })}
        />
        <Stack.Screen
          name="PostStress"
          component={PostStressScreen}
          options={({ navigation }) => ({
            title: 'Manage Post Exam Stress',
            ...getBackArrowHeader(navigation),
          })}
        />
        <Stack.Screen
          name="PersonalizedQuestions1"
          component={PersonalizedQuestions1Screen}
          options={({ navigation }) => ({
            title: 'PersonalizedQuestions1',
            ...getBackArrowHeader(navigation),
          })}
        />
      
        <Stack.Screen
          name="ThankYou"
          component={ThankYouScreen}
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({});
